import React, { useState } from 'react';
import Header from './components/Header';
import CategoryTabs from './components/CategoryTabs';
import ProductGrid from './components/ProductGrid';
import ActionButtons from './components/ActionButtons';
import Footer from './components/Footer';
import { categories } from './data/menu';
import { BasketProvider, useBasket } from './components/BasketContext';
import AIAssistantModal from './components/Modals/AIAssistantModal';
import BasketModal from './components/Modals/BasketModal';

const AppContent: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState(categories[0].id);
  const [activeTab, setActiveTab] = useState('menu');
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [showBasket, setShowBasket] = useState(false);
  
  const { addToBasket, totalItems } = useBasket();
  
  const activeCategoryItems = categories.find(
    category => category.id === activeCategory
  )?.items || [];
  
  return (
    <div className="min-h-screen bg-neutral-50 pb-20 font-sans">
      <Header />
      
      <main>
        <CategoryTabs 
          categories={categories} 
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
        />
        
        <div className="relative pb-16">
          <h2 className="text-xl font-semibold text-coffee-800 px-4 pt-4 pb-2">
            {categories.find(c => c.id === activeCategory)?.name}
          </h2>
          
          <ProductGrid 
            items={activeCategoryItems}
            onAddToBasket={addToBasket}
          />
        </div>
      </main>
      
      <ActionButtons 
        basketCount={totalItems}
        onViewBasket={() => setShowBasket(true)}
        onCallAssistant={() => setShowAIAssistant(true)}
        onViewOrders={() => {}}
      />
      
      <Footer 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />
      
      <AIAssistantModal 
        isOpen={showAIAssistant}
        onClose={() => setShowAIAssistant(false)}
      />
      
      <BasketModal
        isOpen={showBasket}
        onClose={() => setShowBasket(false)}
      />
    </div>
  );
};

function App() {
  return (
    <BasketProvider>
      <AppContent />
    </BasketProvider>
  );
}

export default App;