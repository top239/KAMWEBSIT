import { Category, MenuItem } from '../types';

export const menuItems: MenuItem[] = [
  // Coffee
  {
    id: 1,
    name: 'Espresso',
    description: 'Our signature espresso crafted with precision extraction',
    price: 12,
    currency: 'CAD',
    category: 'coffee',
    image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    popular: true
  },
  {
    id: 2,
    name: 'Americano',
    description: 'Perfect water-to-espresso ratio for balanced flavor',
    price: 10,
    currency: 'CAD',
    category: 'coffee',
    image: 'https://images.pexels.com/photos/2638019/pexels-photo-2638019.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  },
  {
    id: 3,
    name: 'Cappuccino',
    description: 'Expertly crafted foam with ideal texture and temperature',
    price: 14,
    currency: 'CAD',
    category: 'coffee',
    image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    popular: true
  },
  
  // Specialty Lattes
  {
    id: 4,
    name: 'Coconut Cold Brew',
    description: 'Cold brew infused with coconut cream and a hint of vanilla',
    price: 15,
    currency: 'CAD',
    category: 'specialty-lattes',
    image: 'https://images.pexels.com/photos/2396220/pexels-photo-2396220.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 5,
    name: 'Saffron Cardamom Latte',
    description: 'Middle Eastern inspired latte with premium saffron and cardamom',
    price: 16,
    currency: 'CAD',
    category: 'specialty-lattes',
    image: 'https://images.pexels.com/photos/3879495/pexels-photo-3879495.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    popular: true
  },
  {
    id: 6,
    name: 'Rosewater Pistachio Latte',
    description: 'Fragrant rosewater with crushed pistachios and espresso',
    price: 17,
    currency: 'CAD',
    category: 'specialty-lattes',
    image: 'https://images.pexels.com/photos/985865/pexels-photo-985865.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  
  // Desserts
  {
    id: 7,
    name: 'Lounge Lava Cake',
    description: 'Warm chocolate cake with molten center served with vanilla ice cream',
    price: 10,
    currency: 'CAD',
    category: 'desserts',
    image: 'https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 8,
    name: 'Baklava Cheesecake',
    description: 'Fusion dessert with layers of phyllo, honey, and cheesecake',
    price: 12,
    currency: 'CAD',
    category: 'desserts',
    image: 'https://images.pexels.com/photos/1126359/pexels-photo-1126359.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    popular: true
  },
  {
    id: 9,
    name: 'Saffron Rice Pudding',
    description: 'Creamy rice pudding infused with saffron and rose',
    price: 9,
    currency: 'CAD',
    category: 'desserts',
    image: 'https://images.pexels.com/photos/4397920/pexels-photo-4397920.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 13,
    name: 'Tres Leches Cake',
    description: 'Traditional Mexican sponge cake soaked in three types of milk, topped with whipped cream and caramel drizzle',
    price: 10,
    currency: 'CAD',
    category: 'desserts',
    image: 'https://images.pexels.com/photos/6133171/pexels-photo-6133171.jpeg',
    popular: true
  },
  
  // Non-Coffee
  {
    id: 10,
    name: 'Hibiscus Iced Tea',
    description: 'Refreshing hibiscus tea with hints of berry and citrus',
    price: 8,
    currency: 'CAD',
    category: 'non-coffee',
    image: 'https://images.pexels.com/photos/792613/pexels-photo-792613.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 11,
    name: 'Golden Turmeric Latte',
    description: 'Warming non-coffee latte with turmeric, ginger and almond milk',
    price: 13,
    currency: 'CAD',
    category: 'non-coffee',
    image: 'https://images.pexels.com/photos/5946641/pexels-photo-5946641.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 12,
    name: 'Matcha Dream',
    description: 'Ceremonial grade matcha whisked to perfection with oat milk',
    price: 14,
    currency: 'CAD',
    category: 'non-coffee',
    image: 'https://images.pexels.com/photos/5946630/pexels-photo-5946630.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    popular: true
  },
  {
    id: 14,
    name: 'Tea',
    description: 'A selection of premium loose leaf teas served in a traditional teapot',
    price: 12,
    currency: 'CAD',
    category: 'non-coffee',
    image: 'https://images.pexels.com/photos/1417945/pexels-photo-1417945.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  }
];

export const categories: Category[] = [
  {
    id: 'coffee',
    name: 'Coffee',
    icon: '☕',
    items: menuItems.filter(item => item.category === 'coffee')
  },
  {
    id: 'specialty-lattes',
    name: 'Specialty Lattes',
    icon: '🧋',
    items: menuItems.filter(item => item.category === 'specialty-lattes')
  },
  {
    id: 'desserts',
    name: 'Desserts',
    icon: '🧁',
    items: menuItems.filter(item => item.category === 'desserts')
  },
  {
    id: 'non-coffee',
    name: 'Non-Coffee',
    icon: '🌿',
    items: menuItems.filter(item => item.category === 'non-coffee')
  }
];