import React from 'react';
import { ShoppingBag, Phone, ClipboardList } from 'lucide-react';

interface ActionButtonsProps {
  basketCount: number;
  onViewBasket: () => void;
  onCallAssistant: () => void;
  onViewOrders: () => void;
}

const ActionButtons: React.FC<ActionButtonsProps> = ({ 
  basketCount, 
  onViewBasket, 
  onCallAssistant, 
  onViewOrders 
}) => {
  return (
    <div className="fixed bottom-20 left-0 right-0 px-4 z-10">
      <div className="bg-white rounded-xl shadow-lg p-4 flex flex-col gap-3">
        <button 
          onClick={onViewBasket}
          className={`flex items-center justify-center gap-2 py-3 px-4 rounded-lg text-sm font-medium w-full ${
            basketCount > 0 
              ? 'bg-primary-500 text-white hover:bg-primary-600' 
              : 'bg-neutral-200 text-neutral-600'
          } transition-colors`}
        >
          <ShoppingBag size={18} />
          {basketCount > 0 ? `View Basket (${basketCount})` : 'Basket Empty'}
        </button>
        
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={onCallAssistant}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-lg bg-primary-500 text-white text-sm font-medium hover:bg-primary-600 transition-colors"
          >
            <Phone size={18} />
            Call AI Assistant
          </button>
          
          <button 
            onClick={onViewOrders}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-lg bg-coffee-800 text-white text-sm font-medium hover:bg-coffee-900 transition-colors"
          >
            <ClipboardList size={18} />
            View Orders
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActionButtons