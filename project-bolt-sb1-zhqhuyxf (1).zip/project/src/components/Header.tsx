import React from 'react';
import { Coffee } from 'lucide-react';
import StatusBar from './StatusBar';

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 bg-white z-10 shadow-sm">
      <StatusBar />
      <div className="flex justify-between items-center px-4 py-3">
        <div className="flex items-center gap-2">
          <Coffee size={24} className="text-primary-500" />
          <h1 className="text-xl font-bold text-coffee-800">Hawaa Lounge</h1>
        </div>
        <button className="bg-primary-500 text-white py-1.5 px-3 rounded-full text-sm font-medium hover:bg-primary-600 transition-colors">
          Get App
        </button>
      </div>
    </header>
  );
};

export default Header