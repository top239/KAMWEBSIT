import React, { createContext, useContext, useState, ReactNode } from 'react';
import { BasketItem, MenuItem } from '../types';

interface BasketContextType {
  basketItems: BasketItem[];
  addToBasket: (item: MenuItem) => void;
  removeFromBasket: (itemId: number) => void;
  updateQuantity: (itemId: number, quantity: number) => void;
  clearBasket: () => void;
  totalItems: number;
  subtotal: number;
}

const BasketContext = createContext<BasketContextType | undefined>(undefined);

interface BasketProviderProps {
  children: ReactNode;
}

export const BasketProvider: React.FC<BasketProviderProps> = ({ children }) => {
  const [basketItems, setBasketItems] = useState<BasketItem[]>([]);

  const addToBasket = (item: MenuItem) => {
    setBasketItems(prevItems => {
      const existingItem = prevItems.find(i => i.id === item.id);
      
      if (existingItem) {
        return prevItems.map(i => 
          i.id === item.id 
            ? { ...i, quantity: i.quantity + 1 } 
            : i
        );
      }
      
      return [...prevItems, { ...item, quantity: 1 }];
    });
  };

  const removeFromBasket = (itemId: number) => {
    setBasketItems(prevItems => prevItems.filter(item => item.id !== itemId));
  };

  const updateQuantity = (itemId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromBasket(itemId);
      return;
    }
    
    setBasketItems(prevItems => 
      prevItems.map(item => 
        item.id === itemId 
          ? { ...item, quantity } 
          : item
      )
    );
  };

  const clearBasket = () => {
    setBasketItems([]);
  };

  const totalItems = basketItems.reduce(
    (total, item) => total + item.quantity, 
    0
  );

  const subtotal = basketItems.reduce(
    (total, item) => total + (item.price * item.quantity), 
    0
  );

  return (
    <BasketContext.Provider 
      value={{
        basketItems,
        addToBasket,
        removeFromBasket,
        updateQuantity,
        clearBasket,
        totalItems,
        subtotal
      }}
    >
      {children}
    </BasketContext.Provider>
  );
};

export const useBasket = () => {
  const context = useContext(BasketContext);
  if (context === undefined) {
    throw new Error('useBasket must be used within a BasketProvider');
  }
  return context;
};