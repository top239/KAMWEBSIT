import React from 'react';
import { X, Minus, Plus, ShoppingBag } from 'lucide-react';
import { useBasket } from '../BasketContext';

interface BasketModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const BasketModal: React.FC<BasketModalProps> = ({ isOpen, onClose }) => {
  const { 
    basketItems,
    updateQuantity,
    removeFromBasket,
    subtotal,
    totalItems
  } = useBasket();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-md h-[80vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b">
          <div className="flex items-center">
            <ShoppingBag size={24} className="text-primary-500 mr-2" />
            <h3 className="font-semibold text-coffee-800">Your Basket</h3>
          </div>
          <button onClick={onClose} className="text-neutral-500 hover:text-neutral-700">
            <X size={20} />
          </button>
        </div>
        
        {/* Basket items */}
        <div className="flex-1 overflow-y-auto p-4">
          {basketItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-neutral-500">
              <ShoppingBag size={48} className="mb-4 opacity-30" />
              <p className="text-lg font-medium">Your basket is empty</p>
              <p className="text-sm mt-2">Add items to get started</p>
              <button 
                onClick={onClose}
                className="mt-6 bg-primary-500 text-white py-2 px-4 rounded-lg hover:bg-primary-600 transition-colors"
              >
                Browse Menu
              </button>
            </div>
          ) : (
            <>
              {basketItems.map(item => (
                <div key={item.id} className="flex items-center py-3 border-b last:border-b-0">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                  
                  <div className="ml-3 flex-1">
                    <h4 className="font-medium text-coffee-800">{item.name}</h4>
                    <p className="text-neutral-500 text-sm">{item.currency} {item.price}</p>
                  </div>
                  
                  <div className="flex items-center">
                    <button 
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="p-1 rounded-full bg-neutral-100 hover:bg-neutral-200"
                    >
                      <Minus size={16} />
                    </button>
                    
                    <span className="mx-2 min-w-[24px] text-center">{item.quantity}</span>
                    
                    <button 
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="p-1 rounded-full bg-neutral-100 hover:bg-neutral-200"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
        
        {/* Checkout section */}
        {basketItems.length > 0 && (
          <div className="p-4 border-t">
            <div className="flex justify-between mb-2">
              <span className="text-neutral-600">Subtotal ({totalItems} items)</span>
              <span className="font-medium">{basketItems[0]?.currency} {subtotal.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between mb-4">
              <span className="text-neutral-600">Service Fee</span>
              <span className="font-medium">{basketItems[0]?.currency} {(subtotal * 0.1).toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between mb-4 text-lg font-semibold">
              <span>Total</span>
              <span>{basketItems[0]?.currency} {(subtotal * 1.1).toFixed(2)}</span>
            </div>
            
            <button className="w-full py-3 bg-primary-500 text-white rounded-lg font-medium hover:bg-primary-600 transition-colors">
              Proceed to Checkout
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default BasketModal;