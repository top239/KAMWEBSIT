import React, { useState } from 'react';
import { X, Send, Bot } from 'lucide-react';

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AIAssistantModal: React.FC<AIAssistantModalProps> = ({ isOpen, onClose }) => {
  const [message, setMessage] = useState('');
  const [conversation, setConversation] = useState<{
    role: 'user' | 'assistant';
    content: string;
    timestamp: Date;
  }[]>([
    {
      role: 'assistant',
      content: 'Hello! I\'m your AI assistant for Hawaa Lounge. How can I help you today?',
      timestamp: new Date()
    }
  ]);

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    // Add user message
    const userMessage = {
      role: 'user' as const,
      content: message,
      timestamp: new Date()
    };
    
    setConversation(prev => [...prev, userMessage]);
    setMessage('');
    
    // Simulate AI response after a short delay
    setTimeout(() => {
      const aiResponses = [
        "I'd be happy to help with that! Our specialty today is the Saffron Cardamom Latte.",
        "The AI Espresso is prepared using our custom algorithm that adjusts extraction time based on bean origin and humidity.",
        "Our most popular dessert is the Baklava Cheesecake. It pairs wonderfully with our Neural Cappuccino.",
        "Would you like me to explain our specialty menu options?",
        "I can help you customize any drink to your preferences. Would you like to try something unique?"
      ];
      
      const randomResponse = aiResponses[Math.floor(Math.random() * aiResponses.length)];
      
      const assistantMessage = {
        role: 'assistant' as const,
        content: randomResponse,
        timestamp: new Date()
      };
      
      setConversation(prev => [...prev, assistantMessage]);
    }, 1000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-md h-[80vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b">
          <div className="flex items-center">
            <Bot size={24} className="text-primary-500 mr-2" />
            <h3 className="font-semibold text-coffee-800">AI Assistant</h3>
          </div>
          <button onClick={onClose} className="text-neutral-500 hover:text-neutral-700">
            <X size={20} />
          </button>
        </div>
        
        {/* Chat messages */}
        <div className="flex-1 overflow-y-auto p-4 bg-neutral-50">
          {conversation.map((msg, index) => (
            <div 
              key={index}
              className={`mb-4 ${
                msg.role === 'user' ? 'flex justify-end' : 'flex justify-start'
              }`}
            >
              <div 
                className={`max-w-[80%] p-3 rounded-lg ${
                  msg.role === 'user' 
                    ? 'bg-primary-500 text-white' 
                    : 'bg-white text-coffee-800 border border-neutral-200'
                }`}
              >
                <p>{msg.content}</p>
                <div className={`text-xs mt-1 ${
                  msg.role === 'user' ? 'text-primary-100' : 'text-neutral-400'
                }`}>
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Input area */}
        <div className="p-4 border-t bg-white">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Type your message..."
              className="flex-1 border border-neutral-300 rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-300"
            />
            <button 
              onClick={handleSendMessage}
              disabled={!message.trim()}
              className={`p-2 rounded-full ${
                message.trim() 
                  ? 'bg-primary-500 text-white' 
                  : 'bg-neutral-200 text-neutral-400'
              }`}
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIAssistantModal;