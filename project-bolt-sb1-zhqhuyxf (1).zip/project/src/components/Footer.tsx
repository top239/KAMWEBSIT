import React from 'react';
import { Home, Menu, ClipboardList, User } from 'lucide-react';

interface FooterProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Footer: React.FC<FooterProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: <Home size={20} /> },
    { id: 'menu', label: 'Menu', icon: <Menu size={20} /> },
    { id: 'orders', label: 'Orders', icon: <ClipboardList size={20} /> },
    { id: 'profile', label: 'Profile', icon: <User size={20} /> }
  ];
  
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200 z-10">
      <div className="grid grid-cols-4 py-2">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center justify-center py-1 ${
              activeTab === tab.id 
                ? 'text-primary-500' 
                : 'text-neutral-500 hover:text-neutral-700'
            }`}
          >
            {tab.icon}
            <span className="text-xs mt-1">{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Footer;