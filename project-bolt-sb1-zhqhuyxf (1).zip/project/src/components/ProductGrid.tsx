import React from 'react';
import { MenuItem } from '../types';
import ProductCard from './ProductCard';

interface ProductGridProps {
  items: MenuItem[];
  onAddToBasket: (item: MenuItem) => void;
}

const ProductGrid: React.FC<ProductGridProps> = ({ items, onAddToBasket }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4">
      {items.map(item => (
        <ProductCard 
          key={item.id} 
          item={item} 
          onAddToBasket={onAddToBasket} 
        />
      ))}
    </div>
  );
};

export default ProductGrid;