import React from 'react';
import { MenuItem } from '../types';
import { Star } from 'lucide-react';

interface ProductCardProps {
  item: MenuItem;
  onAddToBasket: (item: MenuItem) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ item, onAddToBasket }) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300 border border-neutral-100">
      <div className="relative">
        <img 
          src={item.image} 
          alt={item.name} 
          className="w-full h-40 object-cover"
        />
        {item.popular && (
          <div className="absolute top-2 left-2 bg-primary-500 text-white text-xs py-1 px-2 rounded-full flex items-center">
            <Star size={12} className="mr-1" /> Popular
          </div>
        )}
        <div className="absolute -bottom-3 right-3 bg-white rounded-full px-2 py-1 shadow-md border border-neutral-100">
          <span className="text-sm font-medium text-coffee-800">
            {item.currency} {item.price}
          </span>
        </div>
      </div>
      
      <div className="p-4 pt-5">
        <h3 className="font-semibold text-coffee-800 mb-1">{item.name}</h3>
        <p className="text-neutral-600 text-sm line-clamp-2 h-10">{item.description}</p>
        
        <button 
          onClick={() => onAddToBasket(item)}
          className="mt-3 py-1.5 px-3 bg-primary-50 text-primary-700 rounded-full text-sm font-medium hover:bg-primary-100 transition-colors w-full"
        >
          Add to basket
        </button>
      </div>
    </div>
  );
};

export default ProductCard