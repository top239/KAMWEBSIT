import React from 'react';
import { Battery, Signal, Wifi } from 'lucide-react';

const StatusBar: React.FC = () => {
  // Get current time in format "9:41"
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  
  return (
    <div className="flex justify-between items-center px-4 py-2 text-xs font-medium">
      <div>{time}</div>
      <div className="flex items-center gap-1">
        <Signal size={12} className="text-black" />
        <span>5G</span>
        <Wifi size={12} className="ml-1 text-black" />
        <Battery size={14} className="ml-1 text-black" />
      </div>
    </div>
  );
};

export default StatusBar;