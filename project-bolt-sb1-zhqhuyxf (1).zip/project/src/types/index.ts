export interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  currency: string;
  category: 'coffee' | 'specialty-lattes' | 'desserts' | 'non-coffee';
  image: string;
  popular?: boolean;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  items: MenuItem[];
}

export interface BasketItem extends MenuItem {
  quantity: number;
}

export interface StatusIndicator {
  time: string;
  batteryLevel: number;
  networkType: string;
  wifiStrength: number;
}